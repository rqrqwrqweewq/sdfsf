function getRandomKey() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
    const randomIndex = Math.floor(Math.random() * characters.length);
    return characters[randomIndex];
}

let key = getRandomKey();

let logger = `Вы нажали ${key} !!!`;

console.log(logger);
