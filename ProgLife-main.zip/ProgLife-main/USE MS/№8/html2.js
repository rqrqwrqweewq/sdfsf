const isEven = (number) => number % 2 === 0 ? "четное" : "нечетное";

console.log(isEven(4)); // "четное"
console.log(isEven(7)); // "нечетное"
