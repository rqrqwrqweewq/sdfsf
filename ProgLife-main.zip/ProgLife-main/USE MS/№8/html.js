function circleArea(radius) {
  const pi = Math.PI; 
  return pi * Math.pow(radius, 2); 
}

console.log(circleArea(5)); // 78.53981633974483
